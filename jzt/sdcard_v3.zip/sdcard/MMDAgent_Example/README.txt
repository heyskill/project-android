===============================================================================
                     MMDAgent "Sample Script" version 1.4
                           release December 25, 2013


The work is released as a part of MMDAgent (http://www.mmdagent.jp/).

*******************************************************************************
                                    Copying
*******************************************************************************

See README.txt and COPYRIGHT.txt in each content directory.

*******************************************************************************
                                  How to try
*******************************************************************************

Drag and drop MMDAgent_Example.mdf on MMDAgent.exe.

*******************************************************************************
                               Acknowledgements
*******************************************************************************

Keiichi Tokuda
Akinobu Lee
Keiichiro Oura

*******************************************************************************
                                  Who we are
*******************************************************************************

The MMDAgent project team is a voluntary group for developing the Toolkit for
Building Voice Interaction System. Current members are

 Keiichi Tokuda      http://www.sp.nitech.ac.jp/~tokuda/
 Akinobu Lee         http://www.sp.nitech.ac.jp/~ri/
 Keiichiro Oura      http://www.sp.nitech.ac.jp/~uratec/
 Daisuke Yamamoto    http://yamamoto.web.nitech.ac.jp/member/yamamoto/yamamoto.html

and the members are dynamically changing. The current formal contact address of
MMDAgent project team and a mailing list for MMDAgent users can be found at
http://www.mmdagent.jp/
===============================================================================
