●『ねんどろいど風・初音ミク』PMDデータのご利用ありがとうございます。
Thank you for using my PMD-data "Nendoroid Miku Hatsune".

●キャラクター規約について
・キャラクターの規約に関しては以下のリンク先にある内容に準じてください。
・このキャラクターの権利はピアプロ・キャラクター・ライセンス（PCL、 http://piapro.jp/license/pcl ）
・キャラクター利用ガイドライン（http://piapro.jp/license/character_guideline）
Agreement for Character Model Usage
* Please read and agree the following hyperlinked page(s) upon usage of any data.


・当モデルのモチーフとさせていただいた、グッドスマイルカンパニー『ねんどろいど』シリーズの
イメージを損なうような使い方はしないでください。
* Please be sure to use this appropriately, and avoid any action that will spoil its
  image and plot provided by the creator.

●モデルデータについて
・当モデルの報告が無い再配布は私が管理できなくなりますので、おやめください。
About the Model Data
* Any redistribution of this model without my permission is strictly prohibited, as
  I will be unable to manage them all.

・モデルデータの改造に関しては特に制限しておりません。
その際は、改造してできたキャラクターの規約に準じてください。
改造したモデルの配布に関しても特に制限するつもりはありません。
ただしそれによって起きた問題には一切責任を負いかねます、ご自身の責任でお願いします。
例文）当モデルデータは『エナメルＰ/ハッチ』の制作したものを元にしていますが、
改造してできた当モデルの責任は『エナメルＰ/ハッチ』には一切無いものとします。
* I will not set any restriction on modification of this model data.
  Please clarify and follow ALL agreement your modified data will have to.
  And also, I will not set any restriction on redistribution of such modified data.
  However, please clarify that the one who will be responsible to any problems caused
  from that data is you, not me.
i.e.) This model data is created from "Enamel-P/Hacchi" model, but he/she will be
      exempted from all responsibilities.


・当データを使用しての商用利用に関しては、キャラクターの権利者に了解を得た上でご連絡ください。
・イベント等で頒布される作品に使用したい場合も一度ご連絡いただけると幸いです。
* If you plan to redistribute any data using my data for commercial purpose, please
  agree and follow to ALL agreement that you will have to.
* If you plan to distribute data on any event, please contact me in advance.



Please enjoy my data! 



//////////////////////////////////////////////////////////////
10/07/18

エナメルＰ/ハッチ
ブログ→http://blog.goo.ne.jp/hachi800
にゃっぽん→http://v-nyappon.net/?m=pc&a=page_f_home&target_c_member_id=4289
ツイッター→http://twitter.com/enamel_hachi
メール→hachi800@goo.jp

11/02/20：suttokoさんのPMDデータに、ででさんが改良を施したデータに変更
