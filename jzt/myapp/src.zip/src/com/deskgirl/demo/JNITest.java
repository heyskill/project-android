package com.deskgirl.demo;

/**
 * Created by h4x on 15/4/20.
 */
public class JNITest
{
    public static String getStringFromJava()
    {
        return "stringFromJava";
    }

    public String getStringFromJavaClass()
    {
        return "stirngFromJavaClass";
    }
}
